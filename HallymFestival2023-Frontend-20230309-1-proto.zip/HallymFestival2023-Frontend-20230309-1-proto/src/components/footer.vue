<template>
  <div class="footer">
    <h3>한림대학교 멋쟁이사자처럼 Builder Team</h3>
    <p>Hallym Likelion</p>
  </div>
</template>
<style scoped>
.footer {
  text-align: center;
  background-color: darkgray;
}
</style>